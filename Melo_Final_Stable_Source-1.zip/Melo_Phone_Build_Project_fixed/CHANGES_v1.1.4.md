# v1.1.4 changes

- Splash screen is shorter (same animation, played faster): the app is usable about 1 second sooner.
- Sleep timer: a timer chosen before any music is playing is no longer lost; it starts when playback starts.
- Tapping a song in the Songs tab now always queues the Songs list (or the current search results) from that song.
  With Shuffle on, the tapped song plays first and the rest are shuffled.

Not compiled with Gradle here (no Android SDK). Web page re-tested headlessly.
