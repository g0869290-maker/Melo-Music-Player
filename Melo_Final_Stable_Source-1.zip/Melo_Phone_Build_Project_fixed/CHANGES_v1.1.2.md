# v1.1.2 changes

- App Info: "Created by" reads **Ganesh Kagne** (confirmed; already correct in v1.1.1).

## Speed / smoothness
- Splash artwork moved out of index.html into `assets/img/` (page 416 KB -> 124 KB, so it parses and paints sooner); the wordmark was also downscaled (150 KB -> 95 KB).
- Returning to the app no longer freezes the page: `libraryVersion()` (Android 11+) lets the page skip the blocking `scanAudio()` call when the media library has not changed.
- Infinite scroll appends the next 200 rows instead of rebuilding the whole list (no scroll jump, no repeated full re-render).
- Off-screen song rows use `content-visibility:auto`, so long libraries scroll with far less layout/paint work.
- Tapping a heart updates only the hearts; it no longer re-renders the whole song list.
- Playlist / album / liked pages flip the playing state in place instead of rebuilding every row on each play/pause.
- Finishing the album-art backfill patches covers in place instead of re-rendering everything.
- Mini-player glass blur reduced (22px -> 14px) - cheaper while scrolling.
- Removed the 30-step startup polling of the native player and the per-2-second rebuild of the full queue; the queue is only rebuilt when it actually changes.

## Bug fixes
- Native: `loadCover()` could throw `RejectedExecutionException` (crash) if the page asked for a cover just as the screen closed; now guarded.
- Native: cover results are no longer delivered to a destroyed/finishing WebView.

Not compiled with Gradle here (no Android SDK in this environment). The web page was smoke-tested headlessly with a stubbed Android bridge and 1000 fake songs.
