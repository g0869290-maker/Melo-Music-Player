package com.melo.music

import android.app.PendingIntent
import android.content.Intent
import android.media.audiofx.Equalizer
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Shared in-process state between the activity bridge and the playback service. */
object PlaybackHub {
    /** Equalizer gains in millibels for the 5 bands (60 Hz, 230, 910, 3.6k, 14k). */
    @Volatile var eq = IntArray(5)
    @Volatile var service: PlaybackService? = null
    /** Sleep timer chosen in Settings (0 = off); applied when the service starts if it was set before music played. */
    @Volatile var sleepMinutes = 0
    /** Crossfade length in ms chosen in Settings (0 = off). */
    @Volatile var crossfadeMs = 0
    /** Pause when headphones are unplugged / Bluetooth disconnects. */
    @Volatile var pauseOnNoisy = true
}

/**
 * Native music playback. ExoPlayer plays the songs; a MediaSession exposes them to the system, which
 * draws the notification, the lock-screen controls and handles headset / Bluetooth buttons. Because
 * this service owns playback, music keeps playing, and stays controllable, after the app is closed.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var coverLoader: CoverBitmapLoader? = null
    private var equalizer: Equalizer? = null
    private var exo: ExoPlayer? = null
    // crossfade: a second, short-lived player finishes the old song's tail while the main player starts the next one
    private var ghost: ExoPlayer? = null
    private var ghostEq: Equalizer? = null
    private var ghostItemId: String? = null
    private var ghostActive = false
    private var fadeStartMs = 0L
    private val xfTick = object : Runnable {
        override fun run() {
            try { tickCrossfade() } catch (_: Exception) { dropGhost() }
            if (PlaybackHub.crossfadeMs > 0 || ghost != null) sleepHandler.postDelayed(this, 80)
        }
    }
    private val sleepHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val sleepTask = Runnable { session?.player?.pause() }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(PlaybackHub.pauseOnNoisy)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = attachEqualizer(audioSessionId)
        })
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        coverLoader = CoverBitmapLoader(applicationContext)
        session = MediaSession.Builder(this, player)
            .setSessionActivity(open)
            .setBitmapLoader(coverLoader!!)
            .build()
        setMediaNotificationProvider(DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat_melo) })
        exo = player
        PlaybackHub.service = this
        if (PlaybackHub.sleepMinutes > 0) setSleepTimer(PlaybackHub.sleepMinutes)
        attachEqualizer(player.audioSessionId)
        applyOptions()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Swiping the app away keeps music playing, but a paused/idle service shouldn't linger in memory. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    /** Pauses playback after [minutes]; 0 cancels the timer. */
    fun setSleepTimer(minutes: Int) {
        sleepHandler.removeCallbacks(sleepTask)
        if (minutes > 0) sleepHandler.postDelayed(sleepTask, minutes * 60_000L)
    }

    /** Applies the crossfade length and the headphone-disconnect option from Settings. */
    fun applyOptions() {
        exo?.setHandleAudioBecomingNoisy(PlaybackHub.pauseOnNoisy)
        sleepHandler.removeCallbacks(xfTick)
        if (PlaybackHub.crossfadeMs > 0) sleepHandler.post(xfTick) else dropGhost()
    }

    private fun tickCrossfade() {
        val p = exo ?: return
        val xf = PlaybackHub.crossfadeMs.toLong()
        if (xf <= 0L) { dropGhost(); return }
        val g = ghost
        if (ghostActive && g != null) {
            val f = ((SystemClock.elapsedRealtime() - fadeStartMs).toFloat() / xf).coerceIn(0f, 1f)
            p.volume = f
            g.volume = 1f - f
            g.playWhenReady = p.playWhenReady // pausing during a fade pauses both
            if (f >= 1f || g.playbackState == Player.STATE_ENDED) dropGhost()
            return
        }
        if (!p.isPlaying || p.repeatMode == Player.REPEAT_MODE_ONE || !p.hasNextMediaItem()) {
            if (g != null) dropGhost()
            return
        }
        val dur = p.duration
        val cur = p.currentMediaItem
        if (cur == null || dur == C.TIME_UNSET || dur < xf * 3) {
            if (g != null) dropGhost()
            return
        }
        val remaining = dur - p.currentPosition
        if (g != null && (ghostItemId != cur.mediaId || remaining > xf + 6000L)) { dropGhost(); return }
        if (g == null) {
            if (remaining > xf && remaining <= xf + 4000L) prepareGhost(cur, dur - xf)
            return
        }
        if (remaining <= xf && g.playbackState == Player.STATE_READY) {
            ghostActive = true
            fadeStartMs = SystemClock.elapsedRealtime()
            g.volume = 1f
            g.play()
            p.volume = 0f
            p.seekToNextMediaItem()
        }
    }

    private fun prepareGhost(item: androidx.media3.common.MediaItem, startMs: Long) {
        val g = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(),
                /* handleAudioFocus = */ false
            )
            .build()
        g.setMediaItem(item, startMs)
        g.playWhenReady = false
        g.prepare()
        ghost = g
        ghostItemId = item.mediaId
        ghostActive = false
        val sid = g.audioSessionId
        if (sid != C.AUDIO_SESSION_ID_UNSET && sid != 0) {
            ghostEq = try { Equalizer(0, sid).also { applyBands(it) } } catch (_: Exception) { null }
        }
    }

    private fun dropGhost() {
        ghostActive = false
        ghostItemId = null
        ghostEq?.release()
        ghostEq = null
        ghost?.release()
        ghost = null
        exo?.volume = 1f
    }

    /** Applies PlaybackHub.eq to the player's audio session. */
    fun applyEq() {
        val eq = equalizer ?: return
        applyBands(eq)
    }

    private fun applyBands(eq: Equalizer) {
        try {
            val range = eq.bandLevelRange
            val bands = minOf(eq.numberOfBands.toInt(), PlaybackHub.eq.size)
            for (i in 0 until bands) {
                eq.setBandLevel(i.toShort(), PlaybackHub.eq[i].coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
            eq.enabled = PlaybackHub.eq.any { it != 0 }
        } catch (_: Exception) {
            // Some devices do not support the equalizer effect; playback is unaffected.
        }
    }

    private fun attachEqualizer(sessionId: Int) {
        equalizer?.release()
        equalizer = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        equalizer = try { Equalizer(0, sessionId) } catch (_: Exception) { null }
        applyEq()
    }

    override fun onDestroy() {
        sleepHandler.removeCallbacks(sleepTask)
        sleepHandler.removeCallbacks(xfTick)
        dropGhost()
        exo = null
        PlaybackHub.service = null
        equalizer?.release()
        equalizer = null
        coverLoader?.close()
        coverLoader = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}
