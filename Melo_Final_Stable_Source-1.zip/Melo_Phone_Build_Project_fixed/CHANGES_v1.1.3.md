# v1.1.3 changes (second audit pass)

## Bug fixes
- First 12 rows/cards after opening the app or switching tabs kept their entrance animation applied forever. That overrode the tap "press" squish on those rows and kept them on their own GPU layers. The animation class is now removed when the animation ends.

## Speed / smoothness
- Album art for device songs is now fetched as a normal image request from the app's own origin (`/cover/<id>`). Before, every cover was turned into base64, pushed through the JS bridge on the main thread, parsed as a string and decoded again. Now the browser fetches it on a background thread. This removes thousands of main-thread hops on first launch / after adding music.
- Cover database writes are batched (one transaction per 25 songs instead of one per song).
- Song tiles use 12 shared CSS colour classes instead of a long inline `color-mix()` gradient on every row (smaller markup, less style work per row).
- Albums grid uses `content-visibility:auto` like the song list.
- HTML escaping uses a constant lookup table instead of building an object for every character.

## Cleanup
- Removed the now-unused native cover executor, `loadCover()` bridge method and `deliverCover()` (fewer threads, less code, no more 8-second cover timeouts).

Not compiled with Gradle here (no Android SDK). Web page re-tested headlessly with 1000 fake songs: scroll, likes, collections, search, reload-skips-scan, cover fetch/batched save, palette classes, animation-class cleanup. No JavaScript errors.
