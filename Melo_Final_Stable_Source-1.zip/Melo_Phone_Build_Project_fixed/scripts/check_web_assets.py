#!/usr/bin/env python3
"""Validate bundled HTML inline JavaScript and Android XML resources."""
from html.parser import HTMLParser
from pathlib import Path
import subprocess
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "app/src/main/assets/index.html"

class Scripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_script = False
        self.external = False
        self.parts = []
        self.scripts = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "script":
            self.in_script = True
            self.external = any(k.lower() == "src" for k, _ in attrs)
            self.parts = []

    def handle_data(self, data):
        if self.in_script and not self.external:
            self.parts.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "script" and self.in_script:
            if not self.external:
                self.scripts.append("".join(self.parts))
            self.in_script = False
            self.external = False

parser = Scripts()
parser.feed(HTML.read_text(encoding="utf-8"))
if not parser.scripts:
    raise SystemExit("No inline JavaScript blocks found")

with tempfile.TemporaryDirectory() as temp:
    for index, source in enumerate(parser.scripts, 1):
        path = Path(temp) / f"inline-{index}.js"
        path.write_text(source, encoding="utf-8")
        subprocess.run(["node", "--check", str(path)], check=True)

xml_files = list((ROOT / "app/src/main").rglob("*.xml"))
for path in xml_files:
    ET.parse(path)

print(f"Validated {len(parser.scripts)} inline JavaScript blocks and {len(xml_files)} XML files.")
