# v1.1.6 changes

## Smoothness
- Seek bar and time: between the native 500 ms position reports the page advances the clock itself, so the bar glides instead of stepping. The thumb now moves with `transform` (no `left`), and the frame loop runs only while Now Playing is open and playing.
- Now Playing: drag down to close. The sheet follows your finger and then either closes or settles back.
- Mini-player art flies into the Now Playing cover (transform + opacity on one small element). Skipped in Light animations mode and with reduced motion.
- Settings, App Info and playlist pages: swipe right anywhere, or down from the header, to close (the page follows your finger); the back arrow still works.
- Rows: softer press-and-release scale.

## Gestures
- Swipe left/right between Songs and Albums; the page follows the finger, snaps by distance or speed, and resists at the edges.
- Swipe left/right in Now Playing between Song and Lyrics.

## Settings that now work
- **Crossfade between songs** (on/off) and **Crossfade length** (2-12 s). Native playback now does a real overlap: shortly before a song ends a second short-lived player finishes its tail while the main player starts the next song, volumes ramp in opposite directions, and the equalizer is applied to both. No crossfade for repeat-one, the last song with repeat off, very short songs, or when you skip manually.
- **Pause when headphones disconnect** is now applied by the native service (it used to be always on).
- **Keep playing in background**: when off, playback pauses when the app is hidden or the screen locks (works for native playback too).
- **Sleep timer** presets: Off, 5, 10, 15, 30, 45, 60, 90 min.
- All choices are saved and restored on the next start.

## Dialogs
- The three `confirm()` popups (remove from playlist, remove from liked, delete playlist) are now an in-app glass sheet. Android Back closes it.

## Build
- The GitHub Actions build downloads `vendor/jsmediatags.min.js` when it is missing. For a local build, download it once (see `vendor/README.txt`).
- versionCode 10 / versionName 1.1.6.

## Not changed
- Release signing is untouched: create your own keystore before sharing the APK.
- Not compiled or run on a device. The page was exercised in headless Chromium with a fake bridge (swipes, drag-to-close, cover flight, seek glide, confirm sheet, every Settings row and player icon): no JS errors from the new code.
- The Kotlin crossfade code (PlaybackService.kt, MainActivity.kt) has NOT been compiled or heard on a device. If the first build reports a compile error, send it to me.
