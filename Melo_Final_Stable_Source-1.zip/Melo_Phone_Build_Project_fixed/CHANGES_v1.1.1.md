# v1.1.1 changes

- App Info: "Created by" now reads **Ganesh Kagne**.

## Performance
- Removed the 22px backdrop blur from the heart button on every song row (largest scroll cost); replaced with a similar translucent fill.
- Waveform: size measured only on resize (no forced layout per frame), gradients cached, DPR capped at 2, steady ~30 fps, stops when no waveform is on screen.
- Album art: native side now returns a ready 320px JPEG (no second decode/re-encode in JS); art is patched into visible rows in place instead of rebuilding lists.
- Images decode asynchronously (`decoding="async"`).
- Library sort uses one shared `Intl.Collator`; search caches lowercase keys.
- jsmediatags is loaded only when an imported song needs it (no CDN request on normal launches).
- No queue-sync polling or fullscreen requests while hidden / inside the Android WebView.
- Progress/time text only written when changed.
- Startup: library loading begins at 250 ms instead of 1 s (splash animation is compositor-only).
- Foreground return reuses the live MediaController instead of rebuilding it each time.
- Playback service stops itself when the app is swiped away while paused.

Not compiled or run on a device here (no Gradle/Android SDK in this environment).
