# v1.1.5 changes - smoother animations

## Why it was janky
- Every big panel (Now Playing, settings pages, queue, equalizer, mini player, tab swipe) used a strong "bounce" curve.
  Full-screen panels visibly overshot their edge and then came back, and ran for 0.6-0.7 s, so more frames to drop.
- The tab pill moved by animating `left`/`width` (layout every frame) and had a second blur on top of the pill's own blur.
- The list area sat inside a 3D perspective context.
- The mini player blurs whatever scrolls behind it, and its waveform canvas redraws 30x/s on top of that blur.

## Changes
- Big surfaces now use an iOS-style deceleration curve with no overshoot and shorter durations (0.45-0.52 s). Small buttons keep the springy tap feel.
- Tab pills (Songs/Albums and Song/Lyrics) slide with `transform` only; segments are equal width.
- Removed perspective/preserve-3d from the pager; row entrance animation is 2D, shorter, with a shorter stagger.
- Search bar opens without height overshoot.
- Now Playing content rises in sequence faster.
- New **Light animations (older phones)** switch in Settings. It turns on automatically for low-RAM / <=4-core phones:
  no live blur on the mini player, lighter shadows, no icon drop-shadow filters, no row-pulse loop, waveform at ~20 fps,
  shorter transitions, big panels do not keep permanent GPU layers.
- Native: asks Android for the display's highest refresh rate (90/120 Hz) and exposes `isLowRam()` to the page.

Not compiled or run on a device here (no Gradle/Android SDK). The page was smoke-tested in headless Chromium: no JS errors, tab thumb and the new toggle work.
