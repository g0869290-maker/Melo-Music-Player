# Source revision fixes

1. Native `nativeState()` reads `MediaController` on the main thread.
2. Controller creation is lifecycle-managed and duplicate connection callbacks are guarded.
3. WebView navigation is restricted to the app's own HTTPS asset origin.
4. Device library refresh occurs after permission handling and when the app returns to the foreground.
5. Native Media3 playback service owns playback independently of the WebView.
6. Failed tracks are skipped with a bounded consecutive-error policy.
7. WebView renderer loss recreates the screen while native playback remains service-owned.
8. Empty scans do not erase an existing device library.
9. Likes and playlists are mirrored to app-private storage.
10. Audio byte-range parsing now validates the entire header and rejects unsatisfiable ranges correctly.
11. Bounded stream reads follow the Java `InputStream` contract.
12. Backup writes preserve the previous good backup until replacement succeeds.
13. Cover-loader worker threads are shut down with the playback service.
14. CI runs JavaScript/XML validation and builds debug and release APKs.

Compilation and physical-device testing remain outstanding until the configured CI workflow and device test checklist have been completed.
