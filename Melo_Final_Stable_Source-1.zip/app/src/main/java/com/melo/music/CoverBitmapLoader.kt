package com.melo.music

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.util.BitmapLoader
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import java.io.File
import java.util.concurrent.Executors

/**
 * Loads the cover shown in the notification and on the lock screen.
 * Art URIs look like melo-art://m/<MediaStore id> or melo-art://f/<imported file name>.
 */
class CoverBitmapLoader(private val context: Context) : BitmapLoader, AutoCloseable {
    private val executor = MoreExecutors.listeningDecorator(Executors.newFixedThreadPool(2))

    override fun supportsMimeType(mimeType: String): Boolean = true

    override fun close() {
        executor.shutdown()
    }

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = executor.submit<Bitmap> {
        BitmapFactory.decodeByteArray(data, 0, data.size) ?: throw IllegalStateException("Cannot decode cover")
    }

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
        if (uri.scheme != "melo-art") return Futures.immediateFailedFuture(UnsupportedOperationException("Unsupported cover uri"))
        return executor.submit<Bitmap> {
            val kind = uri.host
            val key = uri.lastPathSegment ?: throw IllegalStateException("No cover key")
            val bitmap = when (kind) {
                "m" -> key.toLongOrNull()?.let { fromMediaStore(it) }
                "f" -> fromFile(File(importsDir(context), key))
                else -> null
            }
            bitmap ?: throw IllegalStateException("No cover")
        }
    }

    private fun fromMediaStore(id: Long): Bitmap? {
        val songUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
        embedded { it.setDataSource(context, songUri) }?.let { return it }
        val albumId = context.contentResolver.query(songUri, arrayOf(MediaStore.Audio.Media.ALBUM_ID), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L } ?: -1L
        if (albumId <= 0L) return null
        return try {
            context.contentResolver.openFileDescriptor(Uri.parse("content://media/external/audio/albumart/$albumId"), "r")
                ?.use { BitmapFactory.decodeFileDescriptor(it.fileDescriptor, null, BitmapFactory.Options().apply { inSampleSize = 2 }) }
        } catch (_: Exception) {
            null
        }
    }

    private fun fromFile(file: File): Bitmap? = if (file.exists()) embedded { it.setDataSource(file.absolutePath) } else null

    private fun embedded(source: (MediaMetadataRetriever) -> Unit): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            source(retriever)
            val bytes = retriever.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Exception) {
            null
        } finally {
            retriever.release()
        }
    }
}

/** Folder holding imported songs copied from the page so the native player can read them. */
fun importsDir(context: Context): File = File(context.filesDir, "imports").apply { mkdirs() }
