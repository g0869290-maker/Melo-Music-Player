package com.melo.music

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.MimeTypeMap
import android.webkit.RenderProcessGoneDetail
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val coverExecutor: ExecutorService = Executors.newFixedThreadPool(2)

    // Native playback: the player lives in PlaybackService; this controller talks to it.
    private var controller: MediaController? = null
    private var connecting = false
    private val pendingNative = mutableListOf<(MediaController) -> Unit>()
    private val ui = Handler(Looper.getMainLooper())
    private var errorStreak = 0
    private val ticker = object : Runnable {
        override fun run() {
            // Only talk to the page while music is actually playing; the listener covers pause/resume.
            if (controller?.isPlaying == true) pushPlayerState()
            ui.postDelayed(this, 500)
        }
    }
    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) errorStreak = 0
            pushPlayerState()
        }
        // A broken or unsupported file: skip to the next song instead of freezing (give up after 5 in a row).
        override fun onPlayerError(error: PlaybackException) {
            val c = controller ?: return
            errorStreak++
            try {
                if (errorStreak <= 5 && c.hasNextMediaItem()) { c.seekToNextMediaItem(); c.prepare(); c.play() }
                else c.pause()
            } catch (_: Exception) {}
            pushPlayerState()
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = pushPlayerState()
        override fun onPlaybackStateChanged(playbackState: Int) = pushPlayerState()
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = pushPlayerState()
    }

    // File picker for the page's <input type="file"> (audio import and cover image).
    // Permission prompts. Uses the activity-result API instead of overriding onRequestPermissionsResult.
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED) refreshWebLibrary()
    }

    private val pickAudio = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { onPicked(it) }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { onPicked(it) }

    override fun onStart() {
        super.onStart()
        // While the app was in the background the system may have stopped PlaybackService.
        // A controller kept from before then silently ignores every tap, so reconnect on each start.
        controller?.let { old ->
            try { old.removeListener(playerListener); old.release() } catch (_: Exception) {}
        }
        controller = null
        connecting = false
        connectController()
        ui.removeCallbacks(ticker)
        ui.post(ticker)
        // Pick up songs added or removed while the app was in the background.
        if (checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED) refreshWebLibrary()
    }

    override fun onStop() {
        controller?.removeListener(playerListener)
        ui.removeCallbacks(ticker)
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Let the page extend behind the camera cut-out / status-bar area instead of leaving a black strip.
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        enterImmersiveMode()
        // Chrome remote debugging (chrome://inspect) is available only in debug builds.
        WebView.setWebContentsDebuggingEnabled((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0)

        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                // Pages and audio are served over https://appassets.androidplatform.net (see shouldInterceptRequest),
                // so the page and the audio share one origin and Web Audio (EQ/fades) is not muted.
                allowFileAccess = false
                cacheMode = WebSettings.LOAD_DEFAULT
                loadsImagesAutomatically = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
            }
            addJavascriptInterface(AndroidBridge(), "MeloAndroid")
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView?,
                    callback: ValueCallback<Array<Uri>>?,
                    params: WebChromeClient.FileChooserParams?
                ): Boolean {
                    if (callback == null) return false
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    val wantsImage = params?.acceptTypes?.any { it.contains("image") } == true
                    return try {
                        if (wantsImage) pickImage.launch("image/*") else pickAudio.launch("audio/*")
                        true
                    } catch (_: Exception) {
                        fileCallback = null
                        callback.onReceiveValue(null)
                        false
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                // If the web page's process dies (e.g. out of memory), rebuild the screen instead of crashing the app.
                // Music keeps playing because it lives in PlaybackService.
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    runOnUiThread { recreate() }
                    return true
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val u = request?.url ?: return true
                    return !(u.scheme == "https" && u.host == HOST)
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    if (uri.scheme != "https" || uri.host != HOST) return super.shouldInterceptRequest(view, request)
                    val path = uri.path ?: return notFound()
                    return try {
                        when {
                            path.startsWith("/audio/") -> {
                                val id = uri.lastPathSegment?.toLongOrNull() ?: return notFound()
                                val range = request?.requestHeaders?.entries
                                    ?.firstOrNull { it.key.equals("range", ignoreCase = true) }?.value
                                audioResponse(id, range)
                            }
                            path.startsWith("/assets/") -> assetResponse(path.removePrefix("/assets/"))
                            else -> notFound()
                        }
                    } catch (_: Exception) {
                        notFound()
                    }
                }
            }
        }
        setContentView(web)
        web.loadUrl("$ORIGIN/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // The page closes its own sheets and pages first; only then does the app leave.
                web.evaluateJavascript("(function(){return !!(window.meloAndroidBack&&window.meloAndroidBack())})()") { result ->
                    if (result != "true") moveTaskToBack(false)
                }
            }
        })
        ensureAudioPermission()
        // The controller is connected in onStart(), which always runs right after onCreate().
    }

    private fun onPicked(uris: List<Uri>) {
        val callback = fileCallback
        fileCallback = null
        callback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
    }

    private fun notFound() = WebResourceResponse("text/plain", "utf-8", 404, "Not found", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    /** Serves a bundled file from app/src/main/assets (the player page, vendor scripts, branding). */
    private fun assetResponse(name: String): WebResourceResponse {
        if (name.isEmpty() || name.contains("..")) return notFound()
        val stream = try { assets.open(name) } catch (_: Exception) { return notFound() }
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = when (ext) {
            "html" -> "text/html"
            "js" -> "text/javascript"
            "css" -> "text/css"
            "json" -> "application/json"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
        val encoding = if (mime.startsWith("text/") || mime == "application/json") "utf-8" else null
        return WebResourceResponse(mime, encoding, stream)
    }

    /**
     * Serves a device song to the player. Supports HTTP Range requests, which the
     * audio element uses for seeking and for reading the duration.
     */
    private fun audioResponse(id: Long, rangeHeader: String?): WebResourceResponse {
        val mediaUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
        val mime = contentResolver.getType(mediaUri) ?: "audio/mpeg"
        val afd = contentResolver.openAssetFileDescriptor(mediaUri, "r") ?: return notFound()
        val total = if (afd.length >= 0) afd.length else mediaSize(id)
        val stream = afd.createInputStream()
        if (total < 0) {
            return WebResourceResponse(mime, null, 200, "OK", mapOf("Accept-Ranges" to "none"), stream)
        }

        // Accept exactly one RFC 9110 byte range. A malformed/unsupported Range header
        // is ignored (full response); a syntactically valid but unsatisfiable range is 416.
        val match = rangeHeader?.trim()?.let { RANGE.matchEntire(it) }
        var start = 0L
        var end = total - 1
        if (match != null) {
            val fromText = match.groupValues[1]
            val toText = match.groupValues[2]
            val from = fromText.toLongOrNull()
            val to = toText.toLongOrNull()
            val valid = when {
                fromText.isEmpty() -> toText.isNotEmpty() && to != null && to > 0L
                else -> from != null && from >= 0L && (toText.isEmpty() || (to != null && to >= from))
            }
            if (!valid) {
                stream.close()
                return rangeNotSatisfiable(mime, total)
            }
            if (fromText.isEmpty()) {
                // suffix range: "bytes=-500" means the last 500 bytes
                start = maxOf(0L, total - (to ?: 0L))
            } else {
                start = from ?: 0L
                end = to?.let { minOf(it, total - 1L) } ?: (total - 1L)
            }
            if (start >= total || start > end) {
                stream.close()
                return rangeNotSatisfiable(mime, total)
            }
        }
        val length = end - start + 1
        if (start > 0) stream.channel.position(start)

        val partial = match != null
        val headers = mutableMapOf("Accept-Ranges" to "bytes", "Content-Length" to length.toString())
        if (partial) headers["Content-Range"] = "bytes $start-$end/$total"
        return WebResourceResponse(
            mime, null,
            if (partial) 206 else 200,
            if (partial) "Partial Content" else "OK",
            headers,
            BoundedInputStream(stream, length)
        )
    }

    private fun rangeNotSatisfiable(mime: String, total: Long) = WebResourceResponse(
        mime, null, 416, "Range Not Satisfiable",
        mapOf("Content-Range" to "bytes */$total", "Accept-Ranges" to "bytes"),
        ByteArrayInputStream(ByteArray(0))
    )

    private fun mediaSize(id: Long): Long {
        val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
        contentResolver.query(uri, arrayOf(MediaStore.Audio.Media.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getLong(0)
        }
        return -1L
    }

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun ensureAudioPermission() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(audioPermission()) != PackageManager.PERMISSION_GRANTED) needed += audioPermission()
        // Android 13+: the playback notification needs this runtime permission.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
        else refreshWebLibrary()
    }

    private fun refreshWebLibrary() {
        if (::web.isInitialized) web.postDelayed({
            web.evaluateJavascript("window.meloRefreshDeviceLibrary&&window.meloRefreshDeviceLibrary()", null)
        }, 350)
    }


    // ---------- native playback (page -> PlaybackService) ----------

    private fun connectController() {
        if (connecting || controller != null) return
        connecting = true
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                if (controller != null) { c.release(); return@addListener } // a newer connection already won
                controller = c
                c.addListener(playerListener)
                pendingNative.toList().forEach { it(c) }
                pendingNative.clear()
                if (::web.isInitialized) web.evaluateJavascript("window.meloNativeReady&&window.meloNativeReady()", null)
                ui.removeCallbacks(ticker)
                ui.post(ticker)
            } catch (_: Exception) {
                connecting = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else {
            pendingNative.add(block)
            connectController()
        }
    }

    private fun stateJson(c: MediaController): JSONObject = JSONObject().apply {
        put("id", c.currentMediaItem?.mediaId ?: "")
        put("playing", c.isPlaying || (c.playWhenReady && c.playbackState == Player.STATE_BUFFERING))
        put("pos", c.currentPosition)
        put("dur", if (c.duration == C.TIME_UNSET) 0L else c.duration)
        put("ended", c.playbackState == Player.STATE_ENDED)
    }

    private fun pushPlayerState() {
        val c = controller ?: return
        if (!::web.isInitialized || c.mediaItemCount == 0) return
        web.evaluateJavascript("window.meloNative&&window.meloNative(${stateJson(c)})", null)
    }

    private fun buildItems(json: String): List<MediaItem> {
        val arr = JSONArray(json)
        val dir = importsDir(this)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val key = o.getString("m")
            val imported = o.optString("k") == "f"
            val uri = if (imported) Uri.fromFile(File(dir, key))
            else Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, key)
            MediaItem.Builder()
                .setMediaId(o.getString("i"))
                .setUri(uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(cleanTag(o.optString("t")) ?: "Unknown title")
                        .setArtist(cleanTag(o.optString("a")))
                        .setAlbumTitle(cleanTag(o.optString("al")))
                        .setDisplayTitle(cleanTag(o.optString("t")) ?: "Unknown title")
                        .setArtworkUri(Uri.parse("melo-art://${if (imported) "f" else "m"}/$key"))
                        .build()
                )
                .build()
        }
    }

    /** Blank and placeholder tags ("<unknown>", "Unknown artist"...) become null so the system card shows nothing instead of junk. */
    private fun cleanTag(v: String?): String? {
        val t = v?.trim().orEmpty()
        if (t.isEmpty() || t.equals("<unknown>", true) || t.matches(Regex("(?i)unknown (artist|album|title)"))) return null
        return t
    }

    private fun repeatMode(rep: Int) = when (rep) {
        1 -> Player.REPEAT_MODE_ALL
        2 -> Player.REPEAT_MODE_ONE
        else -> Player.REPEAT_MODE_OFF
    }

    private fun applyEq(json: String) {
        try {
            val a = JSONArray(json)
            PlaybackHub.eq = IntArray(5) { i -> Math.round(a.optDouble(i, 0.0) * 100).toInt() }
            PlaybackHub.service?.applyEq()
        } catch (_: Exception) {
        }
    }

    private fun enterImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    override fun onDestroy() {
        // Playback continues in PlaybackService; only this screen's link to it is released.
        ui.removeCallbacks(ticker)
        controller?.let { it.removeListener(playerListener); it.release() }
        controller = null
        coverExecutor.shutdownNow()
        if (::web.isInitialized) {
            web.removeJavascriptInterface("MeloAndroid")
            web.stopLoading()
            web.loadUrl("about:blank")
            web.destroy()
        }
        super.onDestroy()
    }

    // ---------- album art for device songs ----------

    /** Embedded tag art first, then the album's MediaStore art. Returns a small JPEG data URL. */
    private fun extractCover(id: Long): String? {
        val uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
        val bitmap = embeddedArt(uri) ?: albumArt(id) ?: return null
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
        bitmap.recycle()
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun embeddedArt(uri: Uri): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            val bytes = retriever.embeddedPicture ?: return null
            decodeScaled(bytes)
        } catch (_: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    private fun albumArt(id: Long): Bitmap? {
        val songUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
        val albumId = contentResolver.query(songUri, arrayOf(MediaStore.Audio.Media.ALBUM_ID), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L } ?: -1L
        if (albumId <= 0L) return null
        return try {
            decodeAlbumArt(Uri.parse("content://media/external/audio/albumart/$albumId"))
        } catch (_: Exception) {
            null
        }
    }

    private fun decodeAlbumArt(art: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openFileDescriptor(art, "r")?.use { BitmapFactory.decodeFileDescriptor(it.fileDescriptor, null, bounds) }
        if (bounds.outWidth <= 0) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight) }
        return contentResolver.openFileDescriptor(art, "r")?.use { BitmapFactory.decodeFileDescriptor(it.fileDescriptor, null, opts) }
    }

    private fun decodeScaled(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight) }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun sampleFor(width: Int, height: Int): Int {
        var sample = 1
        while (width / (sample * 2) >= COVER_PX && height / (sample * 2) >= COVER_PX) sample *= 2
        return sample
    }

    private fun deliverCover(key: String, dataUrl: String?) {
        runOnUiThread {
            if (!::web.isInitialized) return@runOnUiThread
            val arg = if (dataUrl == null) "null" else JSONObject.quote(dataUrl)
            web.evaluateJavascript("window.meloCoverReady&&window.meloCoverReady(${JSONObject.quote(key)},$arg)", null)
        }
    }

    // ---------- JavaScript bridge (page -> app) ----------

    inner class AndroidBridge {
        @JavascriptInterface
        fun hasAudioPermission(): Boolean = checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED

        /** Returns the device's music as JSON, or null if the library could not be read. */
        @JavascriptInterface
        fun scanAudio(): String? {
            if (!hasAudioPermission()) return null
            val projection = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DATE_MODIFIED,
                MediaStore.Audio.Media.MIME_TYPE
            )
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
            val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            val cursor: Cursor = try {
                contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null, sort)
                    ?: return null
            } catch (_: Exception) {
                return null
            }
            val out = JSONArray()
            cursor.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    out.put(JSONObject().apply {
                        put("mediaId", id.toString())
                        put("name", c.string(MediaStore.Audio.Media.DISPLAY_NAME, "audio-$id"))
                        put("title", c.string(MediaStore.Audio.Media.TITLE, "Unknown title"))
                        put("artist", c.string(MediaStore.Audio.Media.ARTIST, "Unknown artist"))
                        put("album", c.string(MediaStore.Audio.Media.ALBUM, "Unknown album"))
                        put("duration", c.long(MediaStore.Audio.Media.DURATION, 0L))
                        put("size", c.long(MediaStore.Audio.Media.SIZE, 0L))
                        put("modified", c.long(MediaStore.Audio.Media.DATE_MODIFIED, 0L) * 1000L)
                        put("mime", c.string(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg"))
                        put("streamUrl", "$ORIGIN/audio/$id")
                    })
                }
            }
            return out.toString()
        }

        // ----- native playback -----

        @JavascriptInterface
        fun hasNativePlayer(): Boolean = true

        /**
         * Plays [id]. [queueJson] is the full playback queue, or empty when the native queue is unchanged
         * and only the current song changes.
         */
        @JavascriptInterface
        fun nativePlay(queueJson: String, id: String, rep: Int, eqJson: String) {
            applyEq(eqJson)
            runOnUiThread {
                withController { c ->
                    c.repeatMode = repeatMode(rep)
                    if (queueJson.isNotEmpty()) {
                        val items = buildItems(queueJson)
                        val index = items.indexOfFirst { it.mediaId == id }.coerceAtLeast(0)
                        c.setMediaItems(items, index, 0L)
                    } else {
                        var index = -1
                        for (i in 0 until c.mediaItemCount) if (c.getMediaItemAt(i).mediaId == id) { index = i; break }
                        if (index >= 0) c.seekTo(index, 0L)
                    }
                    c.prepare()
                    c.play()
                }
            }
        }

        /** Crossfade switch and length from the web settings. Applies to the next song change. */
        @JavascriptInterface
        fun setCrossfade(on: Boolean, seconds: Double) {
            PlaybackHub.xfOn = on
            PlaybackHub.xfSec = seconds.coerceIn(0.5, 12.0)
        }

        /** Replaces the upcoming/previous songs without interrupting the current one. */
        @JavascriptInterface
        fun nativeSetQueue(queueJson: String, currentId: String, rep: Int) {
            runOnUiThread {
                withController { c ->
                    c.repeatMode = repeatMode(rep)
                    if (c.mediaItemCount == 0) return@withController
                    val items = buildItems(queueJson)
                    val playingId = c.currentMediaItem?.mediaId ?: currentId
                    val cur = c.currentMediaItemIndex
                    if (c.mediaItemCount > cur + 1) c.removeMediaItems(cur + 1, c.mediaItemCount)
                    if (cur > 0) c.removeMediaItems(0, cur)
                    val p = items.indexOfFirst { it.mediaId == playingId }
                    if (p < 0) {
                        c.addMediaItems(items)
                    } else {
                        if (p > 0) c.addMediaItems(0, items.subList(0, p))
                        if (p < items.size - 1) c.addMediaItems(items.subList(p + 1, items.size))
                    }
                }
            }
        }

        @JavascriptInterface
        fun nativeSetRepeat(rep: Int) { runOnUiThread { withController { it.repeatMode = repeatMode(rep) } } }

        @JavascriptInterface
        fun nativeResume() {
            runOnUiThread {
                withController { c ->
                    // After an error or a restarted service the player is idle; it must be prepared before play().
                    if (c.playbackState == Player.STATE_IDLE && c.mediaItemCount > 0) c.prepare()
                    c.play()
                }
            }
        }

        @JavascriptInterface
        fun nativePause() { runOnUiThread { withController { it.pause() } } }

        @JavascriptInterface
        fun nativeSeek(ms: Long) { runOnUiThread { withController { it.seekTo(ms) } } }

        @JavascriptInterface
        fun nativeStop() {
            runOnUiThread { withController { it.stop(); it.clearMediaItems() } }
        }

        @JavascriptInterface
        fun setEq(eqJson: String) = applyEq(eqJson)

        /** Sleep timer lives in the playback service so it still fires when the app is closed. 0 cancels. */
        @JavascriptInterface
        fun nativeSleep(minutes: Int) { runOnUiThread { PlaybackHub.service?.setSleepTimer(minutes) } }

        /** Same as nativeSleep, with the option to let the current song finish before pausing. */
        @JavascriptInterface
        fun nativeSleep2(minutes: Int, finishSong: Boolean) { runOnUiThread { PlaybackHub.service?.setSleepTimer(minutes, finishSong) } }

        /** Likes and playlists are mirrored to a file in app storage, in case the WebView's storage is wiped. */
        @JavascriptInterface
        fun saveBackup(json: String): Boolean = try {
            val dir = this@MainActivity.filesDir
            val tmp = File(dir, "melo-backup.json.tmp")
            FileOutputStream(tmp).use { out ->
                out.write(json.toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
            val target = File(dir, "melo-backup.json")
            val previous = File(dir, "melo-backup.json.previous")
            if (previous.exists()) previous.delete()
            val hadTarget = target.exists()
            val previousMoved = !hadTarget || target.renameTo(previous)
            if (!previousMoved) {
                false
            } else if (tmp.renameTo(target)) {
                previous.delete()
                true
            } else {
                if (hadTarget) previous.renameTo(target)
                false
            }
        } catch (_: Exception) {
            false
        }

        @JavascriptInterface
        fun loadBackup(): String = try {
            val f = File(this@MainActivity.filesDir, "melo-backup.json")
            if (f.exists()) f.readText(Charsets.UTF_8) else ""
        } catch (_: Exception) {
            ""
        }

        /** What the native player is doing right now, so the page can pick up after the app was reopened. */
        @JavascriptInterface
        fun nativeState(): String {
            // JavaScript bridge calls arrive on a background thread, but MediaController may only be used
            // from the main thread. Run the read on the main thread and wait briefly for the answer.
            val task = java.util.concurrent.FutureTask<String>(java.util.concurrent.Callable<String> {
                val c = controller
                if (c == null || c.mediaItemCount == 0) {
                    ""
                } else {
                    stateJson(c).also { o ->
                        val ids = JSONArray()
                        for (i in 0 until c.mediaItemCount) ids.put(c.getMediaItemAt(i).mediaId)
                        o.put("ids", ids)
                        o.put("rep", when (c.repeatMode) { Player.REPEAT_MODE_ALL -> 1; Player.REPEAT_MODE_ONE -> 2; else -> 0 })
                    }.toString()
                }
            })
            ui.post(task)
            return try { task.get(1, java.util.concurrent.TimeUnit.SECONDS) } catch (_: Exception) { "" }
        }

        // ----- imported songs: the page copies them into app storage so the native player can read them -----

        @JavascriptInterface
        fun hasImport(name: String, size: Long): Boolean {
            val f = File(importsDir(this@MainActivity), safeName(name))
            return f.exists() && f.length() == size
        }

        /** Appends one base64 chunk of an imported song. [first] starts a fresh file. */
        @JavascriptInterface
        fun importChunk(name: String, base64: String, first: Boolean): Boolean = try {
            FileOutputStream(File(importsDir(this@MainActivity), safeName(name)), !first).use {
                it.write(Base64.decode(base64, Base64.DEFAULT))
            }
            true
        } catch (_: Exception) {
            false
        }

        @JavascriptInterface
        fun deleteImport(name: String) {
            try { File(importsDir(this@MainActivity), safeName(name)).delete() } catch (_: Exception) {}
        }

        /** Extracts a song's cover off the UI thread; the result arrives via window.meloCoverReady. */
        @JavascriptInterface
        fun loadCover(mediaId: String) {
            val id = mediaId.toLongOrNull()
            if (id == null) {
                deliverCover(mediaId, null)
                return
            }
            coverExecutor.execute {
                val data = try { extractCover(id) } catch (_: Exception) { null }
                deliverCover(mediaId, data)
            }
        }
    }

    private fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun Cursor.string(column: String, fallback: String): String {
        val i = getColumnIndex(column)
        if (i < 0 || isNull(i)) return fallback
        // MediaStore reports untagged artist/album as the literal text "<unknown>", not null.
        val v = getString(i)?.trim()
        return if (v.isNullOrEmpty() || v.equals("<unknown>", ignoreCase = true)) fallback else v
    }

    private fun Cursor.long(column: String, fallback: Long): Long {
        val i = getColumnIndex(column)
        return if (i >= 0 && !isNull(i)) getLong(i) else fallback
    }

    /** Wraps a stream so it returns at most [remaining] bytes (one requested range). */
    private class BoundedInputStream(private val inner: InputStream, private var remaining: Long) : InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = inner.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (off < 0 || len < 0 || len > b.size - off) throw IndexOutOfBoundsException()
            if (len == 0) return 0
            if (remaining <= 0) return -1
            val n = inner.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun available(): Int = minOf(remaining, inner.available().toLong()).toInt().coerceAtLeast(0)

        override fun close() = inner.close()
    }

    private companion object {
        const val HOST = "appassets.androidplatform.net"
        const val ORIGIN = "https://appassets.androidplatform.net"
        const val COVER_PX = 320
        val RANGE = Regex("bytes=(\\d*)-(\\d*)", RegexOption.IGNORE_CASE)
    }
}
