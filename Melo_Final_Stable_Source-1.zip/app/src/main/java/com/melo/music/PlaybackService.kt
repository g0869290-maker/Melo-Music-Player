package com.melo.music

import android.app.PendingIntent
import android.content.Intent
import android.media.audiofx.Equalizer
import android.util.Log
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Shared in-process state between the activity bridge and the playback service. */
object PlaybackHub {
    /** Equalizer gains in millibels for the 5 bands (60 Hz, 230, 910, 3.6k, 14k). */
    @Volatile var eq = IntArray(5)
    @Volatile var service: PlaybackService? = null
    /** Crossfade switch and length in seconds, pushed from the web settings. */
    @Volatile var xfOn = false
    @Volatile var xfSec = 4.0
}

/**
 * Native music playback. ExoPlayer plays the songs; a MediaSession exposes them to the system, which
 * draws the notification, the lock-screen controls and handles headset / Bluetooth buttons. Because
 * this service owns playback, music keeps playing, and stays controllable, after the app is closed.
 *
 * Crossfade: when the current song nears its end, a second ExoPlayer ("fader") starts the next song
 * at volume 0 and both players are ramped against each other. When the ramp finishes, the main player
 * jumps to the next song at the fader's position and the fader is released. Any pause, skip or
 * track change during the fade cancels it and restores the main player at full volume.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var coverLoader: CoverBitmapLoader? = null
    private var equalizer: Equalizer? = null
    private val sleepHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var sleepFinishSong = false
    private val sleepTask = Runnable {
        val p = session?.player
        if (sleepFinishSong && p != null && p.isPlaying) {
            // let the current song finish, then pause on its own
            (p as? ExoPlayer)?.pauseAtEndOfMediaItems = true
        } else {
            p?.pause()
        }
    }

    // ---- crossfade state (all touched on the main thread only) ----
    private val xfHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var fader: ExoPlayer? = null
    private var faderEq: Equalizer? = null
    private var fadeLenMs = 0L
    private var fadeStartMs = -1L
    private val fadeTick = Runnable { tickCrossfade() }
    private val watchTask = object : Runnable {
        override fun run() {
            watchCrossfade()
            xfHandler.postDelayed(this, WATCH_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = attachEqualizer(audioSessionId)
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                    player.pauseAtEndOfMediaItems = false
                }
                // Any pause (button, headset unplug, audio focus loss, sleep timer) ends a crossfade.
                if (!playWhenReady) cancelCrossfade()
            }
            // Next / previous / queue change: a crossfade in progress no longer matches the queue.
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = cancelCrossfade()
        })
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        coverLoader = CoverBitmapLoader(applicationContext)
        session = MediaSession.Builder(this, player)
            .setSessionActivity(open)
            .setBitmapLoader(coverLoader!!)
            .build()
        setMediaNotificationProvider(GlassNotificationProvider(this) { coverLoader })
        PlaybackHub.service = this
        attachEqualizer((player as ExoPlayer).audioSessionId)
        xfHandler.post(watchTask)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Pauses playback after [minutes]; 0 cancels the timer. */
    fun setSleepTimer(minutes: Int, finishSong: Boolean = false) {
        sleepHandler.removeCallbacks(sleepTask)
        sleepFinishSong = finishSong
        (session?.player as? ExoPlayer)?.pauseAtEndOfMediaItems = false
        if (minutes > 0) sleepHandler.postDelayed(sleepTask, minutes * 60_000L)
    }

    /** Applies PlaybackHub.eq to the player's audio session. */
    fun applyEq() {
        equalizer?.let { applyEqTo(it) }
    }

    private fun applyEqTo(target: Equalizer) {
        try {
            val range = target.bandLevelRange
            val bands = minOf(target.numberOfBands.toInt(), PlaybackHub.eq.size)
            for (i in 0 until bands) {
                target.setBandLevel(i.toShort(), PlaybackHub.eq[i].coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
            target.enabled = PlaybackHub.eq.any { it != 0 }
        } catch (_: Exception) {
            // Some devices do not support the equalizer effect; playback is unaffected.
        }
    }

    private fun attachEqualizer(sessionId: Int) {
        equalizer?.release()
        equalizer = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        equalizer = try { Equalizer(0, sessionId) } catch (_: Exception) { null }
        applyEq()
    }

    private fun attachFaderEq(sessionId: Int) {
        faderEq?.release()
        faderEq = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        faderEq = try { Equalizer(0, sessionId) } catch (_: Exception) { null }
        faderEq?.let { applyEqTo(it) }
    }

    // ---------------- crossfade ----------------

    /** Runs every [WATCH_MS]: decides when the next song should start fading in. */
    private fun watchCrossfade() {
        val p = session?.player ?: return
        if (fader != null || !PlaybackHub.xfOn || !p.isPlaying) return
        if ((p as? ExoPlayer)?.pauseAtEndOfMediaItems == true) return   // sleep timer wants a full stop
        if (p.repeatMode == Player.REPEAT_MODE_ONE) return             // same song again: no crossfade
        val next = p.nextMediaItemIndex
        if (next == C.INDEX_UNSET) return                              // last song, nothing to blend into
        val duration = p.duration
        if (duration == C.TIME_UNSET || duration <= 0) return
        val fadeMs = (PlaybackHub.xfSec * 1000).toLong()
        if (duration < fadeMs * 2) return                              // song too short to blend
        val remaining = duration - p.currentPosition
        // Start a little early so the next song is buffered and ready when the ramp begins.
        if (remaining <= fadeMs + PREP_MS) startCrossfade(p, next, fadeMs)
    }

    private fun startCrossfade(p: Player, nextIndex: Int, fadeMs: Long) {
        val f = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ false   // the main player already holds audio focus
            )
            .setHandleAudioBecomingNoisy(false) // the main player pauses us through cancelCrossfade
            .build()
        f.volume = 0f
        f.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = attachFaderEq(audioSessionId)
            override fun onPlayerError(error: PlaybackException) = cancelCrossfade()
        })
        f.setMediaItem(p.getMediaItemAt(nextIndex))
        f.prepare()
        f.playWhenReady = true
        Log.d(XF_TAG, "crossfade start: ${fadeMs}ms")
        fader = f
        fadeLenMs = fadeMs
        fadeStartMs = -1L
        xfHandler.post(fadeTick)
    }

    /** Ramps the outgoing song down and the incoming song up; hands over when finished. */
    private fun tickCrossfade() {
        val f = fader ?: return
        val p = session?.player
        if (p == null) {
            cancelCrossfade()
            return
        }
        if (fadeStartMs < 0) {
            // Wait until the incoming song is actually audible before starting the ramp.
            if (f.playbackState == Player.STATE_READY && f.isPlaying) {
                fadeStartMs = android.os.SystemClock.elapsedRealtime()
            } else {
                xfHandler.postDelayed(fadeTick, TICK_MS)
                return
            }
        }
        val elapsed = android.os.SystemClock.elapsedRealtime() - fadeStartMs
        val t = (elapsed.toFloat() / fadeLenMs).coerceIn(0f, 1f)
        f.volume = t
        p.volume = 1f - t
        if (t >= 1f) finishCrossfade(p, f) else xfHandler.postDelayed(fadeTick, TICK_MS)
    }

    /** Moves the main player onto the incoming song at the exact position and releases the fader. */
    private fun finishCrossfade(p: Player, f: ExoPlayer) {
        val pos = f.currentPosition
        val next = p.nextMediaItemIndex
        Log.d(XF_TAG, "crossfade done, switching to index $next")
        // Clear the fader first so the transition caused by seekTo below is seen as a normal swap.
        fader = null
        xfHandler.removeCallbacks(fadeTick)
        if (next != C.INDEX_UNSET) p.seekTo(next, pos)
        p.volume = 1f
        faderEq?.release()
        faderEq = null
        f.release()
    }

    /** Stops any crossfade in progress and restores the main player to full volume. */
    private fun cancelCrossfade() {
        xfHandler.removeCallbacks(fadeTick)
        val f = fader ?: return
        Log.d(XF_TAG, "crossfade cancelled")
        fader = null
        faderEq?.release()
        faderEq = null
        f.release()
        session?.player?.volume = 1f
    }

    override fun onDestroy() {
        xfHandler.removeCallbacks(watchTask)
        cancelCrossfade()
        sleepHandler.removeCallbacks(sleepTask)
        PlaybackHub.service = null
        equalizer?.release()
        equalizer = null
        coverLoader?.close()
        coverLoader = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }

    private companion object {
        const val XF_TAG = "MeloCrossfade"
        const val WATCH_MS = 100L   // how often the song position is checked
        const val TICK_MS = 16L     // ramp update rate (about one frame)
        const val PREP_MS = 1500L   // time allowed for the incoming song to load
    }
}
