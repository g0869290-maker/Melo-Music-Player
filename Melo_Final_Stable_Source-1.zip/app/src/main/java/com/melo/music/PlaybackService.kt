package com.melo.music

import android.app.PendingIntent
import android.content.Intent
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Shared in-process state between the activity bridge and the playback service. */
object PlaybackHub {
    /** Equalizer gains in millibels for the 5 bands (60 Hz, 230, 910, 3.6k, 14k). */
    @Volatile var eq = IntArray(5)
    @Volatile var service: PlaybackService? = null
}

/**
 * Native music playback. ExoPlayer plays the songs; a MediaSession exposes them to the system, which
 * draws the notification, the lock-screen controls and handles headset / Bluetooth buttons. Because
 * this service owns playback, music keeps playing, and stays controllable, after the app is closed.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var coverLoader: CoverBitmapLoader? = null
    private var equalizer: Equalizer? = null
    private val sleepHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var sleepFinishSong = false
    private val sleepTask = Runnable {
        val p = session?.player
        if (sleepFinishSong && p != null && p.isPlaying) {
            // let the current song finish, then pause on its own
            (p as? ExoPlayer)?.pauseAtEndOfMediaItems = true
        } else {
            p?.pause()
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = attachEqualizer(audioSessionId)
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                    player.pauseAtEndOfMediaItems = false
                }
            }
        })
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        coverLoader = CoverBitmapLoader(applicationContext)
        session = MediaSession.Builder(this, player)
            .setSessionActivity(open)
            .setBitmapLoader(coverLoader!!)
            .build()
        setMediaNotificationProvider(GlassNotificationProvider(this) { coverLoader })
        PlaybackHub.service = this
        attachEqualizer((player as ExoPlayer).audioSessionId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Pauses playback after [minutes]; 0 cancels the timer. */
    fun setSleepTimer(minutes: Int, finishSong: Boolean = false) {
        sleepHandler.removeCallbacks(sleepTask)
        sleepFinishSong = finishSong
        (session?.player as? ExoPlayer)?.pauseAtEndOfMediaItems = false
        if (minutes > 0) sleepHandler.postDelayed(sleepTask, minutes * 60_000L)
    }

    /** Applies PlaybackHub.eq to the player's audio session. */
    fun applyEq() {
        val eq = equalizer ?: return
        try {
            val range = eq.bandLevelRange
            val bands = minOf(eq.numberOfBands.toInt(), PlaybackHub.eq.size)
            for (i in 0 until bands) {
                eq.setBandLevel(i.toShort(), PlaybackHub.eq[i].coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
            eq.enabled = PlaybackHub.eq.any { it != 0 }
        } catch (_: Exception) {
            // Some devices do not support the equalizer effect; playback is unaffected.
        }
    }

    private fun attachEqualizer(sessionId: Int) {
        equalizer?.release()
        equalizer = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId == 0) return
        equalizer = try { Equalizer(0, sessionId) } catch (_: Exception) { null }
        applyEq()
    }

    override fun onDestroy() {
        sleepHandler.removeCallbacks(sleepTask)
        PlaybackHub.service = null
        equalizer?.release()
        equalizer = null
        coverLoader?.close()
        coverLoader = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}
