package com.melo.music

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.FutureCallback
import com.google.common.util.concurrent.Futures

/**
 * Glass-style media notification. The card background is a blurred copy of the song's cover with a
 * translucent white sheen and a soft rim, drawn here because notifications cannot blur the wallpaper.
 * Buttons: previous, play/pause, next. Progress is as of the last update (it refreshes on every
 * play, pause or song change; the system does not tick custom notifications on its own).
 */
class GlassNotificationProvider(
    private val context: Context,
    private val loader: () -> CoverBitmapLoader?
) : MediaNotification.Provider {

    companion object {
        const val CHANNEL_ID = "melo_playback_glass"
        const val NOTIFICATION_ID = 1001
        private const val BG_W = 1040
        private const val BG_H_COLLAPSED = 192
        private const val BG_H_EXPANDED = 444
    }

    private var cachedKey: String? = null
    private var cachedCover: Bitmap? = null

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback
    ): MediaNotification {
        ensureChannel()
        val key = mediaSession.player.currentMediaItem?.mediaMetadata?.artworkUri?.toString()
        if (key != cachedKey) {
            cachedKey = key
            cachedCover = null
            val uri = mediaSession.player.currentMediaItem?.mediaMetadata?.artworkUri
            val l = loader()
            if (uri != null && l != null) {
                Futures.addCallback(l.loadBitmap(uri), object : FutureCallback<Bitmap> {
                    override fun onSuccess(result: Bitmap?) {
                        if (cachedKey != key || result == null) return
                        cachedCover = result
                        onNotificationChangedCallback.onNotificationChanged(build(mediaSession, actionFactory))
                    }
                    override fun onFailure(t: Throwable) {}
                }, ContextCompat.getMainExecutor(context))
            }
        }
        return build(mediaSession, actionFactory)
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: android.os.Bundle): Boolean = false

    private fun build(session: MediaSession, factory: MediaNotification.ActionFactory): MediaNotification {
        val p = session.player
        val md = p.mediaMetadata
        val title = md.title?.toString()?.takeIf { it.isNotBlank() } ?: "Melo"
        val artist = md.artist?.toString().orEmpty()
        val playing = p.playWhenReady && p.playbackState != Player.STATE_ENDED
        val cover = cachedCover
        val thumb = roundedCover(cover, 192)

        val prev = factory.createMediaActionPendingIntent(session, Player.COMMAND_SEEK_TO_PREVIOUS.toLong())
        val toggle = factory.createMediaActionPendingIntent(session, Player.COMMAND_PLAY_PAUSE.toLong())
        val next = factory.createMediaActionPendingIntent(session, Player.COMMAND_SEEK_TO_NEXT.toLong())
        val playIcon = if (playing) R.drawable.g_pause_d else R.drawable.g_play_d

        val small = RemoteViews(context.packageName, R.layout.notif_collapsed).apply {
            setImageViewBitmap(R.id.bg, glass(cover, BG_W, BG_H_COLLAPSED))
            setImageViewBitmap(R.id.cover, thumb)
            setTextViewText(R.id.title, title)
            setTextViewText(R.id.artist, artist)
            setViewVisibility(R.id.artist, if (artist.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE)
            setImageViewResource(R.id.play, playIcon)
            setOnClickPendingIntent(R.id.prev, prev)
            setOnClickPendingIntent(R.id.play, toggle)
            setOnClickPendingIntent(R.id.next, next)
        }

        val dur = if (p.duration == C.TIME_UNSET) 0L else p.duration
        val pos = p.currentPosition.coerceAtLeast(0L)
        val big = RemoteViews(context.packageName, R.layout.notif_expanded).apply {
            setImageViewBitmap(R.id.bg, glass(cover, BG_W, BG_H_EXPANDED))
            setImageViewBitmap(R.id.cover, thumb)
            setTextViewText(R.id.title, title)
            setTextViewText(R.id.artist, artist)
            setViewVisibility(R.id.artist, if (artist.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE)
            setImageViewResource(R.id.play, playIcon)
            setProgressBar(R.id.progress, 1000, if (dur > 0) (pos * 1000 / dur).toInt().coerceIn(0, 1000) else 0, false)
            setTextViewText(R.id.tpos, fmt(pos))
            setTextViewText(R.id.tdur, if (dur > 0) fmt(dur) else "")
            setOnClickPendingIntent(R.id.prev, prev)
            setOnClickPendingIntent(R.id.play, toggle)
            setOnClickPendingIntent(R.id.next, next)
        }

        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_melo)
            .setContentIntent(session.sessionActivity)
            .setDeleteIntent(factory.createMediaActionPendingIntent(session, Player.COMMAND_STOP.toLong()))
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setStyle(MediaStyleNotificationHelper.DecoratedMediaCustomViewStyle(session))
            .setCustomContentView(small)
            .setCustomBigContentView(big)
            .build()
        return MediaNotification(NOTIFICATION_ID, n)
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Music playback", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            )
        }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt()
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ---- drawing ----

    /** Frosted card: blurred cover (or a dark gradient), dark scrim for text contrast, white sheen, soft rim. */
    private fun glass(cover: Bitmap?, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val r = 56f
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        c.clipPath(Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) })
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (cover != null) {
            c.drawBitmap(blurred(cover, w, h), null, rect, paint)
        } else {
            paint.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF2B3A55.toInt(), 0xFF0B0F18.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(rect, paint)
            paint.shader = null
        }
        paint.color = 0x66000000
        c.drawRect(rect, paint)
        paint.shader = LinearGradient(0f, 0f, w * 0.6f, h.toFloat(), 0x38FFFFFF, 0x08FFFFFF, Shader.TileMode.CLAMP)
        c.drawRect(rect, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = 0x66FFFFFF
        c.drawRoundRect(RectF(2f, 2f, w - 2f, h - 2f), r, r, paint)
        return out
    }

    /** Cheap blur: centre-crop to the card's shape, shrink hard, then scale back up with filtering. */
    private fun blurred(src: Bitmap, w: Int, h: Int): Bitmap {
        val tw = 40
        val th = (tw * h / w).coerceAtLeast(6)
        val tiny = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val scale = maxOf(tw.toFloat() / src.width, th.toFloat() / src.height)
        val dw = src.width * scale
        val dh = src.height * scale
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        Canvas(tiny).drawBitmap(src, null, RectF((tw - dw) / 2f, (th - dh) / 2f, (tw + dw) / 2f, (th + dh) / 2f), paint)
        val mid = Bitmap.createScaledBitmap(tiny, tw * 4, th * 4, true)
        return Bitmap.createScaledBitmap(mid, w, h, true)
    }

    private fun roundedCover(src: Bitmap?, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val rect = RectF(0f, 0f, size.toFloat(), size.toFloat())
        c.clipPath(Path().apply { addRoundRect(rect, size * 0.24f, size * 0.24f, Path.Direction.CW) })
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (src != null) {
            val side = minOf(src.width, src.height)
            val sx = (src.width - side) / 2
            val sy = (src.height - side) / 2
            c.drawBitmap(src, android.graphics.Rect(sx, sy, sx + side, sy + side), rect, paint)
        } else {
            paint.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), 0xFF3B4F78.toInt(), 0xFF111827.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(rect, paint)
            paint.shader = null
            ContextCompat.getDrawable(context, R.drawable.ic_stat_melo)?.mutate()?.let { d ->
                val pad = size / 4
                d.setBounds(pad, pad, size - pad, size - pad)
                d.setTint(0xCCFFFFFF.toInt())
                d.draw(c)
            }
        }
        return out
    }
}
