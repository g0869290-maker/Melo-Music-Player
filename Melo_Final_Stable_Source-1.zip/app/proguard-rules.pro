# The WebView calls AndroidBridge methods by name from the page, so R8 must keep them
# together with their @JavascriptInterface annotations.
-keep class com.melo.music.MainActivity$AndroidBridge { *; }
-keepattributes *Annotation*
