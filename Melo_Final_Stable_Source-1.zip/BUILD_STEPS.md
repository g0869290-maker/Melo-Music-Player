# Build Melo for Android

## Recommended: build with GitHub Actions

1. Create or open a GitHub repository.
2. Upload the **contents** of this project folder to the repository root (the root must contain `settings.gradle.kts` and `build.gradle.kts`).
3. Commit to `main`, or open **Actions → Build and validate Melo → Run workflow**.
4. Wait for both validation and Android build jobs to finish successfully.
5. Open the completed workflow run and download `Melo-debug-APK` to install and test, or `Melo-release-APK` for a release build.

The workflow checks inline JavaScript and XML, then builds both Android variants with JDK 17 and Gradle 8.9. A successful cloud build verifies compilation, but it does not replace testing on the Android phones you intend to support.

## Build locally in Android Studio

- Android Studio with Android Gradle Plugin 8.7.3 support
- JDK 17
- Android SDK Platform 35 and a compatible build-tools version
- Gradle 8.9

Open this folder as a project and run **Build → Make Project**. The project currently does not bundle Gradle wrapper files, so use Android Studio's Gradle integration or an installed Gradle 8.9.

## Signing and updates

The release variant can be built without a personal keystore for testing, but it will then use the debug signing key. Before distributing an app or relying on seamless future updates, create and securely back up your own Android signing keystore, fill in `keystore.properties` using `keystore.properties.example`, and keep the same key for every future update. Never share the keystore or its passwords.

## Before everyday use

Install the debug APK on the target phone and test: permission denial and re-grant, scanning a large music library, playback of different audio formats, seeking near the start and end, importing large files, removing imported files, screen-off playback, notification/lock-screen controls, Bluetooth/headset controls, sleep timer, and reopening after Android has reclaimed the app. Repeat on the oldest Android version supported (Android 6.0) and a current Android version where possible.
