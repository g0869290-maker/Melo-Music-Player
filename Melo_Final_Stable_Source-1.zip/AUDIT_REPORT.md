# Melo project verification record

## Project status

This document describes the current source tree. It is not a claim that the app has been tested on every Android device or that software can be guaranteed bug-free.

## Current architecture

- Android WebView shell loads `app/src/main/assets/index.html` from a same-origin HTTPS app-assets origin.
- Native MediaStore scan for device audio with runtime audio permission handling.
- Native byte-range audio streaming for seeking.
- Native AndroidX Media3 ExoPlayer playback service and MediaSession for background playback, system media controls, and lock-screen integration.
- Native album-art loading for MediaStore tracks and imported audio.
- WebView file picker for audio and image selection.
- IndexedDB-backed web library, with a native JSON backup for likes and playlists.
- Imported tracks copied to app-private storage for native playback.

## Fixes included in this source revision

- Range parsing now matches the complete single-range header instead of finding a matching substring. Invalid numeric ranges are rejected, unsatisfiable ranges return HTTP 416, and malformed/unsupported headers are ignored rather than accidentally partially interpreted.
- Bounded audio stream reads now obey the `InputStream` zero-length read and argument-validation contracts.
- Likes/playlists backup replacement now writes and syncs a temporary file, preserves the previous backup until the new file is renamed successfully, and attempts restoration if replacement fails.
- The Media3 cover loader's executor is shut down when the playback service is destroyed.
- CI validates inline JavaScript syntax and Android XML before building debug and release APKs.
- Build instructions distinguish a successful compile from real-device validation and explain release signing-key continuity.

## Verification performed in this workspace

- Two inline JavaScript blocks pass `node --check`.
- All eight Android XML files parse successfully.
- ZIP integrity is checked when the final archive is created.

## Not verified here

This environment does not have Gradle or the Android SDK installed, and network access is unavailable. Therefore Kotlin/Android compilation, APK assembly, emulator tests, and physical-device tests have **not** been completed in this workspace. The GitHub Actions workflow is configured to perform the Android debug and release builds; the first successful run must be reviewed before treating the APK as build-verified.

## Device test checklist

- Fresh install and upgrade install.
- Audio and notification permission granted, denied, and later granted.
- Empty library, large library, media scanner refresh, and removed tracks.
- Audio formats and seeking at the beginning, middle, and end.
- Large audio imports, interrupted imports, duplicate imports, and removal.
- Background playback, screen off, notification controls, lock-screen controls, Bluetooth/headset actions, and audio focus interruptions.
- Sleep timer, app process recreation, WebView renderer recovery, backup restoration, and low-storage behavior.
- Release/minified build and installation/update using the same signing key.
