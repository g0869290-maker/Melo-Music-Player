# Melo Android project — clean GitHub build package

This ZIP contains the Android Gradle project at its root. **Upload/extract the contents of this ZIP into the root of your GitHub repository** (not inside another nested project folder).

## Build an APK with GitHub Actions

1. Create or open your GitHub repository.
2. Upload all files and folders from this ZIP to the repository root, preserving the `.github/workflows/build-melo-apk.yml` path.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Melo APK**, then choose **Run workflow** if it has not started automatically.
6. Open the completed run and download the **Melo-debug-APK** artifact. The release artifact is also provided when the optional release build succeeds.

## Why this workflow is simpler and more reliable

- The Android project is already at the repository root; no nested ZIP extraction or project-root detection is needed.
- It uses JDK 17 and Gradle 8.9, matching Android Gradle Plugin 8.7.3 in this project.
- It validates the bundled HTML JavaScript and Android XML before building.
- The debug APK is uploaded immediately after its successful build. A release/R8 failure cannot prevent the debug APK from being uploaded.
- APK artifacts use compression level 0 because APK files are already compressed; this avoids wasting time recompressing them during upload.

## Included Melo UI changes checked by validation

- Splash logo width increased to 280 design units.
- Splash glow timing updated to 2.2 seconds.
- Splash exit scale updated to 1.07.
- Splash word animation duration updated to 1.25 seconds.
- Swipe left/right between Songs and Albums.
- Swipe up on the mini-player to open Now Playing.
- Swipe down on Now Playing to close it.

The validation script checks that these changes and the required Android project files are present. It also syntax-checks inline JavaScript and parses Android XML resources.

## Release signing

Without a private release keystore, the release APK is signed with the debug key for testing. Do not distribute that build as a production-signed release. Configure a private keystore securely through GitHub Actions secrets before publishing.
