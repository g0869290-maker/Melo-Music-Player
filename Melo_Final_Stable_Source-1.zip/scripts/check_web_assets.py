#!/usr/bin/env python3
"""Validate bundled HTML inline JavaScript and Android XML resources."""
from html.parser import HTMLParser
from pathlib import Path
import subprocess
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "app/src/main/assets/index.html"
REQUIRED_FILES = [
    ROOT / "settings.gradle.kts",
    ROOT / "build.gradle.kts",
    ROOT / "app/build.gradle.kts",
    ROOT / "app/src/main/AndroidManifest.xml",
]
for required in REQUIRED_FILES:
    if not required.is_file():
        raise SystemExit(f"Required Android project file is missing: {required.relative_to(ROOT)}")
if not HTML.is_file():
    raise SystemExit(f"App HTML asset is missing: {HTML.relative_to(ROOT)}")

class Scripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_script = False
        self.external = False
        self.parts = []
        self.scripts = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "script":
            self.in_script = True
            self.external = any(k.lower() == "src" for k, _ in attrs)
            self.parts = []

    def handle_data(self, data):
        if self.in_script and not self.external:
            self.parts.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "script" and self.in_script:
            if not self.external:
                self.scripts.append("".join(self.parts))
            self.in_script = False
            self.external = False

html_text = HTML.read_text(encoding="utf-8")
required_ui_changes = {
    "larger splash logo": "width:calc(var(--u)*280)",
    "smoother splash glow": "animation:glo 2.2s ease-in-out .2s forwards",
    "splash exit scale": "transform:scale(1.07)",
    "longer splash word animation": "animation-duration:1.25s",
    "Songs/Albums swipe": "// Swipe between Songs and Albums",
    "mini-player swipe up": "// Swipe up to open Now Playing",
    "Now Playing swipe down": "// Swipe down to close Now Playing",
}
missing = [label for label, marker in required_ui_changes.items() if marker not in html_text]
if missing:
    raise SystemExit("Missing expected Melo UI changes: " + ", ".join(missing))

parser = Scripts()
parser.feed(HTML.read_text(encoding="utf-8"))
if not parser.scripts:
    raise SystemExit("No inline JavaScript blocks found")

with tempfile.TemporaryDirectory() as temp:
    for index, source in enumerate(parser.scripts, 1):
        path = Path(temp) / f"inline-{index}.js"
        path.write_text(source, encoding="utf-8")
        subprocess.run(["node", "--check", str(path)], check=True)

xml_files = list((ROOT / "app/src/main").rglob("*.xml"))
for path in xml_files:
    ET.parse(path)

print(f"Validated {len(parser.scripts)} inline JavaScript blocks and {len(xml_files)} XML files.")
