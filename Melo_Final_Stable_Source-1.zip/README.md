# Melo Android app

Android Studio project for **Melo**. The player UI is `app/src/main/assets/index.html`, shown in a native WebView. The Kotlin host provides device music access (MediaStore), audio streaming with seeking, album art, the file picker, and Android Back handling.

## Build

1. Open this folder in Android Studio (Ladybug or newer, Android Gradle Plugin 8.7.3, Gradle 8.9+). Android Studio creates the Gradle wrapper on first sync.
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Optional but recommended: put `jsmediatags.min.js` (v3.9.5) into `app/src/main/assets/vendor/`. See `vendor/README.txt`.
4. Run the `app` configuration on a device with USB debugging, or on an emulator.
5. For an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Use the release build type for the final test.

## What this version fixes

- "Add audio files" and the cover picker work on Android (file chooser implemented).
- Device songs get real album art, extracted natively in small thumbnails.
- Seeking works for device songs (HTTP Range support).
- Deleted songs are removed from the library on the next scan. A failed scan never clears the library.
- Android Back closes sheets, dialogs, the equalizer, and Now Playing before leaving the app.
- Turning Shuffle off restores the playlist or album you were playing.
- Audio is stored separately from track metadata, so startup no longer loads every song into memory. Existing libraries migrate automatically on first launch.
- Cover art is stored as 320px thumbnails.
- Library writes are batched in one transaction; long lists load in pages.
- Less work while scrolling and playing: no blur on the mini player, a pulsing row glow that does not repaint the shadow every frame, and a cross-fading background tint.
- Release builds are minified (R8). The JavaScript bridge is kept by `proguard-rules.pro`.
- Dark window theme (no white flash at launch). Adaptive icon uses the logo inside the safe zone.
- App name shows as Melo in the header, Settings > App Info, and the launcher.

## Version 1.1.0: native playback

Music now plays in a native Android service, not in the web page.

- **`PlaybackService`** (AndroidX Media3 `MediaSessionService` + ExoPlayer) owns playback. Android draws the media notification, the lock-screen controls and handles headset / Bluetooth buttons. Playback keeps going, and stays controllable, after the app is swiped away.
- The web UI is a remote control: it sends the queue and commands through the `MeloAndroid` bridge and receives state (position, play/pause, current song) back, including changes made from the notification.
- **Device songs** are read straight from MediaStore. **Imported songs** are copied once, on first play, into app storage (`files/imports`) so the native player can read them.
- **Cover art** in the notification and lock screen comes from `CoverBitmapLoader` (embedded tag art, then MediaStore album art). The in-page tint follows the cover colour as before.
- **EQ**: the 5 bands (60 Hz, 230, 910, 3.6k, 14k) drive Android's system `Equalizer` on the player's audio session.
- Reopening the app while music plays picks up the live state and queue.
- Notification design: see the "Melo Notification Design" canvas (compact, expanded, lock screen; cover-colour tint, glass, amber play button).

Earlier in this line (1.0.2): device audio and the page share one https origin (`https://appassets.androidplatform.net`), `allowFileAccess` is off, release signing via `keystore.properties` (see `keystore.properties.example`; unsigned setups fall back to the debug key), R8 keeps annotations, `allowBackup` is off, rescans refresh changed tags.

Note: the page origin changed in 1.0.2, so IndexedDB data from older test installs starts fresh.

## Known limitations

- **Crossfade is not applied** to native playback (ExoPlayer plays one song at a time). The setting still exists in the UI.
- The notification shows previous / play-pause / next and the system seek bar. The design's extra Like and Repeat buttons are not in the system notification yet; they remain in the app.
- If the native player cannot be used (for example a file cannot be copied), the page falls back to its old in-page audio for that song, which stops when the app is closed.
- `vendor/jsmediatags.min.js` is not bundled; put it there per `vendor/README.txt` (tags of imported songs fall back to the CDN copy until then).
- No Gradle wrapper is included; Android Studio and the GitHub workflow supply Gradle.

**This version has not been compiled or run on a device.** The page logic was checked in a browser against a fake bridge; the Kotlin and Gradle files were reviewed but not built. Build the debug APK first, and expect to fix small compile errors if the first build reports any.

## Testing still required on a device

- Playback, seeking, and duration on device songs, across MP3, M4A, FLAC, and OGG
- Notification, lock-screen controls and headset buttons; playback after swiping the app away; reopening the app mid-song
- EQ changes audible; imported songs play natively after the first-play copy
- Album art on device songs and imported files
- File picker for audio import and cover image
- Back button behaviour with each sheet open
- Smoothness with a 1,000+ song library, before and after the change (use Chrome's remote DevTools for the WebView)


## Audit notes
See `AUDIT_REPORT.md` for the comparison of supplied versions, confirmed included features, and remaining release work. The original logo source is preserved in `app/src/main/assets/branding/melo-logo-original.jpg`.
