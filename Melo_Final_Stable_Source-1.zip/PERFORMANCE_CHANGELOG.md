# Melo performance changes

## Scope
This pass keeps the existing HTML/CSS design, colors, layout, animations, playback controls, and native Media3 playback architecture unchanged.

## Change made
- Reworked album-art backfilling from one long sequential queue into a bounded two-worker queue.
- The two-worker limit matches the native cover extraction executor, avoiding an unbounded number of simultaneous metadata/art requests on mid-range devices.
- Missing artwork no longer holds the entire queue for the former 15-second timeout; each request now gives up after 8 seconds.
- Artwork continues to be persisted in IndexedDB and UI refreshes remain batched, preserving existing behaviour.

## Validation performed
- All inline JavaScript blocks pass `node --check`.
- Android manifest and resource XML files parse successfully.
- ZIP contents were checked after packaging.

## Not yet verified
- Android Gradle compilation / APK assembly: not run because this environment has no Gradle installation or Android SDK.
- Physical-device tests on OPPO Reno 6 5G: not run.
- Frame timing, CPU/GPU use, memory, touch latency, and long-duration playback: require an installed build on the target device.

This is a targeted, low-risk optimisation, not a claim that every performance issue is fixed or that the app is guaranteed lag-free.

## Fix pass (duplicates, lyric sync, lyric search)
- Duplicate songs: a second, looser match (same title, artist and length within 2 s) now runs next to the exact file-size match, both at startup and on device scans. Copies with different file sizes or tags are merged.
- Lyric sync: the follow-scroll animation is shorter (280 ms, was 520 ms), so the highlighted line keeps closer to playback.
- Lyric search: the title cleaner no longer strips ordinary words such as "music" or "video" from titles; it removes only the "official video/audio" style tags.

## Not yet verified
- Build and run on device (OPPO Reno 6 5G). Startup lag and scroll smoothness still need a device profile.

## Cleanup pass
- Removed dead code: an unused JavaScript helper (blurThumbFor) and unused CSS rules (appname, ii, npl, sortSplit, lchip, lchipIn).
- Removed three overlapping status documents (AUDIT_REPORT.md, REVIEW_FIXES.md, README_BUILD_FIRST.md). README.md and BUILD_STEPS.md remain for building.
- Kept: crossfade logging (one line per song), the native queue sync timer, and the WRITE_SETTINGS permission, which the ringtone feature uses.

## Library scan
- The device scan now includes every audio file the phone has indexed (mp3 and others), not only files tagged as music. Ringtones, notification sounds and alarms are still excluded.
- Melo watches the device's audio library. New downloads appear in the list about 1.5 seconds after they are saved, without reopening the app.
- Not compiled here (no Android SDK in the sandbox): build and test on device.
