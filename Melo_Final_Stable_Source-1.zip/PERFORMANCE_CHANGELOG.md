# Melo performance changes

## Scope
This pass keeps the existing HTML/CSS design, colors, layout, animations, playback controls, and native Media3 playback architecture unchanged.

## Change made
- Reworked album-art backfilling from one long sequential queue into a bounded two-worker queue.
- The two-worker limit matches the native cover extraction executor, avoiding an unbounded number of simultaneous metadata/art requests on mid-range devices.
- Missing artwork no longer holds the entire queue for the former 15-second timeout; each request now gives up after 8 seconds.
- Artwork continues to be persisted in IndexedDB and UI refreshes remain batched, preserving existing behaviour.

## Validation performed
- All inline JavaScript blocks pass `node --check`.
- Android manifest and resource XML files parse successfully.
- ZIP contents were checked after packaging.

## Not yet verified
- Android Gradle compilation / APK assembly: not run because this environment has no Gradle installation or Android SDK.
- Physical-device tests on OPPO Reno 6 5G: not run.
- Frame timing, CPU/GPU use, memory, touch latency, and long-duration playback: require an installed build on the target device.

This is a targeted, low-risk optimisation, not a claim that every performance issue is fixed or that the app is guaranteed lag-free.
